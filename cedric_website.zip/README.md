
# Cedric Travel & Airport Assistance Website

This is a ready-to-upload package for GitHub Pages hosting.

## Contents
- index.html : main website page
- images/hero.jpg : compressed hero background image
- favicon.ico : small website icon
- logo.png : placeholder logo

## Instructions
1. Sign up on GitHub and create a public repository.
2. Upload all files and folders to the repository.
3. Go to Settings → Pages → Source → main branch → / (root) → Save.
4. Your website will be live at: https://yourusername.github.io/repository-name/
